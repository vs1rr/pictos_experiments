### picto_generation: 
Code to fine-tune open source image generation models (available on Hugging Face) on arasaac pictograms


### picto_retieval:
Code to retrieve pictograms of keywords for each sentence from a text
