Code to retieve pictograms for associated with each sentence starting from a large text

## Description of files in picto_retrieval:

- Get_Pictos_yake.py: script to identify keywords (using yake) from each sentence of a given text and reteive the pictograms associated with them

- Get_Pictos_yake_meanings.py: similar to Get_Pictos_yake.py, but it also checks the definition/meaning of each possible pictogram for a given keyword and picks the pictogram best associated with the context of the sentence
